# VeriMed BT

**Verificador portátil de medidores de energía monofásicos, controlado por Bluetooth desde una app móvil.**

Proyecto de Título · INACAP · Asignatura HIPI02

![Pantallas del equipo](docs/imagenes/pantallas_equipo.png)

---

## ¿Qué hace?

VeriMed BT compara la energía que registra un medidor eléctrico bajo prueba con la energía medida por un medidor de referencia, y calcula su error porcentual:

```
Eref (Wh) = energía integrada por el medidor de referencia (PZEM-004T)
Emed (Wh) = N pulsos × 1000 / Kc          (Kc = imp/kWh de la placa del medidor)
Error (%) = (Emed − Eref) / Eref × 100     →  APROBADO si |Error| ≤ límite de la clase
```

El ensayo se sincroniza con los pulsos del LED del medidor: empieza en el primer pulso y termina al completar N pulsos.

## Componentes

| Parte | Descripción |
|---|---|
| **Equipo** | ESP32-2432S028 "Cheap Yellow Display" 2,8" (ST7789, táctil XPT2046) |
| **Referencia** | Medidor PZEM-004T v3.0 (V, I, P, FP, f) por UART |
| **Sensor de pulsos** | Fotodiodo/fototransistor con comparador LM393 sobre el LED del medidor |
| **App** | Flutter (Android / iOS), Firebase Authentication, Bluetooth LE |

## Funciones

**Equipo (firmware `verimed_v2`)**
- Interfaz táctil con fuentes suavizadas: mediciones en vivo, ajustes, progreso, resultado e historial.
- Ensayo por pulsos con Kc, N pulsos y clase (±1 % / ±2 %) configurables y guardados en flash.
- Veredicto APROBADO / RECHAZADO en pantalla, LED RGB y pitidos.
- Alarmas de sobretensión, tensión baja, sobrecorriente y falta de señal del PZEM.
- Bluetooth LE visible como "VeriMed BT", con encendido/apagado desde la pantalla.
- **Modo simulación**: funciona sin hardware de medición (medidor virtual con error aleatorio).

**App móvil**
- Inicio de sesión con Firebase (correo verificado).
- Búsqueda y conexión BLE, reconexión automática al último equipo.
- Valores en vivo, gráfico de potencia durante el ensayo y aviso de alarmas.
- Escaneo del número de serie (código de barras / QR) con la cámara.
- Foto del medidor con ubicación GPS y dirección del ensayo.
- Historial local, exportación CSV e informe PDF con trazabilidad: serie y firmware del equipo, ubicación, foto y **huella SHA-256** de los datos.

## Estructura del repositorio

```
verimed-bt/
├── firmware/
│   ├── verimed_v2/              Firmware principal del equipo (Arduino IDE)
│   ├── verimed_diagnostico/     Prueba de PZEM y sensor óptico
│   ├── calibracion_tactil/      Calibración de la pantalla táctil
│   └── tft_espi_config/         User_Setup.h para la librería TFT_eSPI
├── app/                         App Flutter (ver "Cómo armar la app")
│   ├── lib/
│   ├── android/app/src/main/AndroidManifest.xml
│   └── pubspec.yaml
└── docs/
    ├── HARDWARE.md              Qué comprar y cómo conectarlo
    ├── PROTOCOLO_BLE.md         Comunicación equipo ↔ app
    ├── CONFIGURACION_APP.md     Permisos, dependencias y compilación
    └── imagenes/
```

## Puesta en marcha

### Firmware
1. Arduino IDE 2.x con el núcleo **esp32 (Espressif)**. Placa: **ESP32 Dev Module**.
2. Librerías: `TFT_eSPI`, `XPT2046_Touchscreen` y, con hardware real, `PZEM-004T-v30`.
3. Copia `firmware/tft_espi_config/User_Setup.h` en la carpeta de la librería TFT_eSPI.
4. Calibra el táctil con `calibracion_tactil` y pega los valores en `verimed_v2.ino`.
5. **Tools → Partition Scheme → "Huge APP (3MB No OTA/1MB SPIFFS)"** y sube `verimed_v2`.
6. Con el PZEM y el sensor conectados: `USAR_PZEM 1` y `USAR_SENSOR_PULSOS 1`.

### Cómo armar la app
Este repositorio guarda solo los archivos propios del proyecto. Para compilar:
1. Copia aquí, dentro de `app/`, el resto de tu proyecto Flutter (`android/`, `ios/`, `assets/`, etc.).
2. Agrega tus archivos de Firebase (**no se suben al repositorio**, ver `.gitignore`):
   `app/lib/firebase_options.dart` y `app/android/app/google-services.json`.
3. `flutter pub get` y `flutter run -d <id-del-teléfono>` (teléfono físico: el emulador no tiene Bluetooth).

Detalles en [docs/CONFIGURACION_APP.md](docs/CONFIGURACION_APP.md).

## Estado del proyecto

- [x] Interfaz del equipo, Bluetooth LE y app conectada
- [x] Ensayo por pulsos, veredicto, historial y alarmas (modo simulación)
- [x] Escáner de número de serie, foto con GPS e informe PDF con SHA-256
- [ ] Integración del PZEM-004T y del sensor óptico (hardware en camino)
- [ ] Validación y calibración contra medidor patrón
- [ ] Historial en la nube (Firestore), emparejamiento con PIN, ensayo multipunto

## Limitaciones

- El PZEM-004T tiene una exactitud aproximada de ±0,5 %: apto para verificación de medidores clase 2 y, con margen, clase 1, pero **no reemplaza un patrón certificado**.
- Los resultados en modo simulación son ilustrativos y así se indica en la app y en el informe.

## Seguridad

El montaje de ensayo trabaja con **220 V**: usar fusible, caja cerrada y supervisión del laboratorio.
Mantén este repositorio **privado**: la app contiene la URL del servicio de envío de informes.
